# services/rag_service.py
import requests
import time
from typing import List, Optional, Dict, Any # Added Any

class RAGService:
    def __init__(self, app_context): # app_context: AppContext
        self.app_context = app_context
        self.logger = self.app_context.logger
        self.rag_server_url = self.app_context.global_settings.get("RAG_SERVER_URL")
        
        if not self.rag_server_url:
            self.logger.warning("[RAGService] RAG_SERVER_URL not configured. RAG functionality will be disabled.")
        else:
            self.logger.info(f"[RAGService] Initialized. RAG Server URL: {self.rag_server_url}")

    def _call_rag_server(self, endpoint: str, payload: Dict, method: str = "POST") -> Optional[Dict[str, Any]]:
        if not self.rag_server_url:
            self.logger.warning(f"[RAGService] Cannot call RAG server, URL not configured. Endpoint: {endpoint}")
            return None

        url = f"{self.rag_server_url.rstrip('/')}/{endpoint.lstrip('/')}"
        rag_timeout = self.app_context.global_settings.get("RAG_REQUEST_TIMEOUT_S", 20) # Increased default slightly

        try:
            self.logger.debug(f"[RAGService] Calling RAG Server. URL: {url}, Method: {method}, Payload: { {k: v if k not in ['image', 'images'] else '[image_data]' for k, v in payload.items()} }") # Avoid logging full b64
            if method.upper() == "POST":
                response = requests.post(url, json=payload, timeout=rag_timeout)
            # Add GET or other methods if your RAG server uses them for some endpoints
            # elif method.upper() == "GET":
            #     response = requests.get(url, params=payload, timeout=rag_timeout)
            else:
                self.logger.error(f"[RAGService] Unsupported HTTP method: {method}")
                return None
            
            response.raise_for_status() # Raises HTTPError for 4xx/5xx responses
            return response.json()
        except requests.exceptions.Timeout:
            self.logger.error(f"[RAGService] RAG server call timed out ({rag_timeout}s) to {url}")
            return None
        except requests.exceptions.HTTPError as e:
            self.logger.error(f"[RAGService] RAG server HTTP error: {e.response.status_code} - {e.response.text[:200]} for URL {url}")
            return None
        except requests.exceptions.RequestException as e:
            self.logger.error(f"[RAGService] RAG server request failed: {e} for URL {url}")
            return None
        except Exception as e_json: # Catches JSONDecodeError etc.
            self.logger.error(f"[RAGService] Failed to process RAG server response from {url}: {e_json}", exc_info=True)
            return None

    def ingest_text(self, collection_name: str, text_content: str, metadata: Optional[Dict] = None, doc_id: Optional[str] = None):
        """
        Ingests text content by calling the RAG server's /add endpoint.
        The collection_name from this function is currently ignored as the rag_server_mm.py
        uses a single hardcoded collection "multimodal_rag".
        If your server supports multiple collections, you'd pass collection_name in the payload.
        """
        if not self.rag_server_url: return # Already logged in __init__ or _call_rag_server
        if not text_content: self.logger.debug("[RAGService] Empty text for ingestion."); return

        self.logger.info(f"[RAGService] Ingesting text to RAG server: '{text_content[:60].replace(chr(10), ' ')}...' (Collection '{collection_name}' - note: server might use a fixed collection)")
        
        payload = {"text": text_content}
        # If your rag_server_mm.py /add endpoint were to accept metadata or id for text, add them here:
        # if metadata: payload["metadata"] = metadata 
        # if doc_id: payload["id"] = doc_id

        response_data = self._call_rag_server(endpoint="/add", payload=payload, method="POST")
        
        if response_data and response_data.get("status") == "added":
            self.logger.debug(f"[RAGService] Text successfully ingested by RAG server. ID: {response_data.get('id')}")
        elif response_data:
            self.logger.warning(f"[RAGService] RAG server ingestion for text returned: {response_data}")
        else:
            self.logger.error("[RAGService] Failed to ingest text to RAG server (no response or error).")

    def ingest_image_b64(self, collection_name: str, image_b64_data_uri: str, caption: str = "", metadata: Optional[Dict] = None, doc_id: Optional[str] = None):
        """
        Ingests a base64 image by calling the RAG server's /add endpoint.
        """
        if not self.rag_server_url: return
        if not image_b64_data_uri: self.logger.debug("[RAGService] Empty image data URI for ingestion."); return

        self.logger.info(f"[RAGService] Ingesting image to RAG server (caption: '{caption[:50]}...'). (Collection '{collection_name}' - note: server might use a fixed collection)")
        
        payload = {
            "image": image_b64_data_uri,
            "caption": caption
        }
        # if metadata: payload["metadata"] = metadata # If your /add endpoint supports it for images
        # if doc_id: payload["id"] = doc_id

        response_data = self._call_rag_server(endpoint="/add", payload=payload, method="POST")

        if response_data and response_data.get("status") == "added":
            self.logger.debug(f"[RAGService] Image successfully ingested by RAG server. ID: {response_data.get('id')}, Type: {response_data.get('type')}")
        elif response_data:
            self.logger.warning(f"[RAGService] RAG server ingestion for image returned: {response_data}")
        else:
            self.logger.error("[RAGService] Failed to ingest image to RAG server (no response or error).")


    def query_rag(self, collection_name: str, query_text: str, top_k: Optional[int] = 3, 
                  # Add images parameter if your query can be multimodal
                  query_images_b64: Optional[List[str]] = None, 
                  metadata_filter: Optional[Dict] = None) -> Optional[List[str]]:
        """
        Queries the RAG server.
        The collection_name here is for logical grouping on DanzarVLM's side,
        but rag_server_mm.py currently uses one fixed collection "multimodal_rag".
        The query_text is sent to the /query endpoint of your Flask RAG server.
        """
        if not self.rag_server_url: return None
        if not query_text: self.logger.debug("[RAGService] Empty query text."); return []

        profile = self.app_context.active_profile
        # top_k is handled by the RAG server's /query endpoint's default or what it accepts.
        # Your /query endpoint uses n_results=5 for Chroma, but doesn't take top_k as a param.
        # We'll send it anyway, maybe you'll adapt your server later.
        # The `top_k` parameter here is more for the LLMService to indicate preference.
        
        payload = {"query": query_text}
        if query_images_b64: # If querying with images
            payload["images"] = query_images_b64 
        # if metadata_filter: payload["filter"] = metadata_filter # If your /query endpoint supports it

        self.logger.info(f"[RAGService] Querying RAG server with text: '{query_text[:50].replace(chr(10), ' ')}...' (Images: {len(query_images_b64) if query_images_b64 else 0})")
        
        response_data = self._call_rag_server(endpoint="/query", payload=payload, method="POST")

        if response_data and "answer" in response_data: # Check for the 'answer' from LLM
            # Your /query endpoint's response structure: {"query", "sources", "answer", "llm_prompt_sent"}
            # We want to return the "sources" for the LLMService to use as RAG context.
            # The "answer" is the LLM's response *after* RAG, which might not be what LLMService expects from query_rag.
            # Let's adjust to return the source texts.
            
            sources_data = response_data.get("sources", [])
            retrieved_texts: List[str] = []
            if sources_data:
                for source_item in sources_data:
                    # From your rag_server_mm.py, source_item has 'type', 'text', 'caption', 'score'
                    # 'text' in sources_data is already prepared (e.g. "Image with caption: ...")
                    if source_item.get("text"):
                        retrieved_texts.append(source_item["text"])
            
            self.logger.info(f"[RAGService] RAG server query returned {len(retrieved_texts)} source documents. LLM Answer from server: '{response_data.get('answer', '')[:60]}...'")
            return retrieved_texts if retrieved_texts else []
        elif response_data: # Response received but not in expected format
            self.logger.warning(f"[RAGService] RAG server query response in unexpected format: {response_data}")
            return []
        else: # No response or error in _call_rag_server
            self.logger.error("[RAGService] Failed to get valid response from RAG server /query endpoint.")
            return None # Indicates error