# services/llm_service.py

import os
import time
import json
import base64
import random
import re # For Markdown stripping
import cv2
import requests
import queue
import numpy as np
from collections import deque # For in-memory deque
from typing import Optional, Dict, List

from utils.text_utils import trim_sentences
from utils.ocr_utils import OCRProcessor
from core.game_profile import GameProfile

class LLMService:
    def _calculate_next_commentary_delay(self) -> float:
        min_interval = float(self.ctx.global_settings.get("NDI_MIN_RANDOM_COMMENTARY_INTERVAL_S", 30.0))
        max_interval = float(self.ctx.global_settings.get("NDI_MAX_RANDOM_COMMENTARY_INTERVAL_S", 120.0))
        
        if min_interval >= max_interval:
            self.logger.warning(f"[LLMService] Min commentary interval ({min_interval}) was >= max ({max_interval}). Adjusted max to {min_interval + 10.0}.")
            max_interval = min_interval + 10.0 
            
        delay = random.uniform(min_interval, max_interval)
        return delay

    def __init__(self, app_context, audio_service, rag_service):
        self.ctx = app_context
        self.audio_service = audio_service
        self.rag_service = rag_service
        self.logger = self.ctx.logger

        try:
            self.ocr_processor = OCRProcessor(app_context)
            self.logger.info("[LLMService] OCRProcessor initialized successfully.")
        except Exception as e:
            self.logger.error(f"[LLMService] Failed to initialize OCRProcessor: {e}", exc_info=True)
            self.ocr_processor = None

        self.last_vlm_time = 0.0 
        self.next_vlm_commentary_delay = self._calculate_next_commentary_delay() 
        self.logger.info(f"[LLMService] Initial VLM commentary delay set to: {self.next_vlm_commentary_delay:.2f}s")

        # --- Hybrid Memory Initialization ---
        self.commentary_theme_history_deque = deque(maxlen=self.ctx.active_profile.memory_deque_size)
        # We also need to subscribe to profile changes to update deque maxlen
        if hasattr(self.ctx, 'active_profile_change_subscribers'):
             self.ctx.active_profile_change_subscribers.append(self._handle_profile_change_for_memory)
        # --- End Hybrid Memory Initialization ---

        self.logger.info("[LLMService] Initialized.")

    def _handle_profile_change_for_memory(self, new_profile: GameProfile):
        """Updates memory settings when profile changes."""
        new_maxlen = new_profile.memory_deque_size
        if self.commentary_theme_history_deque.maxlen != new_maxlen:
            self.logger.info(f"[LLMService] Profile changed. Updating commentary_theme_history_deque maxlen to {new_maxlen}.")
            # Create a new deque with the new maxlen and populate with existing items
            old_items = list(self.commentary_theme_history_deque)
            self.commentary_theme_history_deque = deque(old_items, maxlen=new_maxlen)


    def _strip_markdown_for_tts(self, text: str) -> str:
        if not text: return ""
        # Remove headings
        text = re.sub(r"^\s*#+\s+", "", text, flags=re.MULTILINE)
        # Remove bold/italics (asterisks and underscores)
        text = text.replace("*", "").replace("_", "")
        # Remove horizontal rules
        text = text.replace("---", "")
        # Remove list item markers (-, +, *) at the beginning of lines
        text = re.sub(r"^\s*[\*\-\+]+\s*", "", text, flags=re.MULTILINE)
        # Normalize excessive newlines/spaces
        text = re.sub(r"\s*\n\s*", "\n", text) # Multiple newlines with spaces to one
        text = re.sub(r" {2,}", " ", text) # Multiple spaces to one
        return text.strip()

    def _call_llm_api(self, payload: dict, endpoint: str = "chat/completions") -> Optional[dict]:
        # ... (same as your last correct version)
        base = self.ctx.global_settings.get("LLAMA_API_BASE_URL")
        if not base:
            self.logger.error("[LLMService] LLAMA_API_BASE_URL missing from global_settings.yaml")
            return None
        url = f"{base.rstrip('/')}/{endpoint.lstrip('/')}"
        default_timeouts = {"connect": 10, "read": 180}
        llm_timeouts_config = self.ctx.global_settings.get("LLM_TIMEOUTS", default_timeouts)
        connect_timeout = llm_timeouts_config.get("connect", default_timeouts["connect"])
        read_timeout = llm_timeouts_config.get("read", default_timeouts["read"])
        timeout = (connect_timeout, read_timeout)
        try:
            self.logger.debug(f"[LLMService] Calling LLM API: {url} with payload keys: {list(payload.keys())}")
            resp = requests.post(url, json=payload, timeout=timeout)
            resp.raise_for_status()
            return resp.json()
        except requests.exceptions.Timeout:
            self.logger.error(f"[LLMService] LLM API call timed out to {url}")
            return None
        except requests.exceptions.RequestException as e:
            self.logger.error(f"[LLMService] LLM API request error: {e}", exc_info=True)
            return None
        except Exception as e:
            self.logger.error(f"[LLMService] LLM API general error: {e}", exc_info=True)
            return None


    def generate_vlm_commentary_from_frame(self, frame_bgr_np: np.ndarray):
        profile = self.ctx.active_profile
        gs = self.ctx.global_settings
        now = time.time()

        if now - self.last_vlm_time < self.next_vlm_commentary_delay:
            return

        if self.ctx.is_in_conversation.is_set():
            convo_to = float(gs.get("CONVERSATION_TIMEOUT_S", 45.0))
            if now - self.ctx.last_interaction_time < convo_to:
                self.logger.debug("[LLMService] Pausing VLM: active conversation.")
                return
            else:
                self.logger.info("[LLMService] Conversation timed out, VLM can resume.")
                self.ctx.is_in_conversation.clear()
                self.last_vlm_time = now 
                self.next_vlm_commentary_delay = self._calculate_next_commentary_delay()
                self.logger.debug(f"Reset VLM timer post-convo. Next: ~{self.next_vlm_commentary_delay:.1f}s.")
                return

        self.logger.info("[LLMService] Attempting VLM commentary...")
        
        # --- Image Encoding, OCR, RAG for current context ---
        # ... (This part is largely the same: encode frame, get OCR)
        ok, buf = cv2.imencode(".png", frame_bgr_np)
        if not ok: # Handle encoding failure
            self.logger.error("[LLMService] Failed to encode frame for VLM.")
            self.last_vlm_time = now; self.next_vlm_commentary_delay = self._calculate_next_commentary_delay(); return
        live_b64 = base64.b64encode(buf).decode('utf-8')
        images_for_vlm = [live_b64] # Assuming current frame is primary, ref image logic can be added if needed

        formatted_ocr_string = "OCR not performed or no text detected."
        if self.ocr_processor:
            # ... (OCR extraction logic as before) ...
            ocr_texts_list = self.ocr_processor.extract_text_from_image(frame_bgr_np)
            if ocr_texts_list: formatted_ocr_string = " | ".join(ocr_texts_list)
            else: formatted_ocr_string = "No text detected by OCR."
            self.logger.debug(f"Formatted OCR: {formatted_ocr_string[:200]}")

        # --- Build Prompt with Hybrid Memory ---
        sys_prompt = profile.system_prompt_commentary
        user_template = getattr(profile, 'user_prompt_template_commentary', "OCR: {ocr_text}. Game: {game_name}. Advice?")
        
        # 1. Deque-based history (most recent themes)
        deque_history_str = ""
        if self.commentary_theme_history_deque:
            deque_history_str = "\n\nTo avoid immediate repetition, you recently commented on:\n"
            for theme in self.commentary_theme_history_deque:
                deque_history_str += f"- {theme}\n"
        
        # 2. RAG-based history (semantically relevant older commentary)
        rag_history_str = ""
        retrieved_rag_history_snippets = []
        if self.rag_service and profile.memory_rag_history_collection_name and profile.memory_rag_vlm_commentary_lookback_k > 0:
            rag_history_query = f"Past commentary topics related to current game situation: {formatted_ocr_string[:150]}"
            self.logger.debug(f"[LLMService] Querying RAG for VLM commentary history with: '{rag_history_query}'")
            retrieved_rag_history_snippets = self.rag_service.query_rag(
                collection_name=profile.memory_rag_history_collection_name,
                query_text=rag_history_query,
                top_k=profile.memory_rag_vlm_commentary_lookback_k,
                # Optional: metadata_filter={"source": "VLM_commentary"}
            ) or []
            if retrieved_rag_history_snippets:
                rag_history_str = "\n\nAlso, looking further back, relevant past topics included:\n"
                # Filter out snippets already covered by the deque to avoid redundancy if RAG returns very recent items
                for snippet_content in retrieved_rag_history_snippets:
                    # Assuming snippet_content is the text. If it's a dict, use snippet_content['text_content']
                    is_in_deque = any(theme in snippet_content for theme in self.commentary_theme_history_deque)
                    if not is_in_deque:
                         rag_history_str += f"- {snippet_content.split('.')[0]}\n" # Summary: first sentence

        instruction_for_new_commentary = "\nPlease provide a NEW, DIFFERENT, and insightful observation or piece of advice based on the current visuals and text, considering the above."

        try:
            user_prompt_filled = user_template.format(
                game_name=profile.game_name,
                ocr_text=formatted_ocr_string
            )
        except KeyError as e:
            self.logger.error(f"Prompt template error: {e}. Template: '{user_template}'"); self.last_vlm_time = now; self.next_vlm_commentary_delay = self._calculate_next_commentary_delay(); return

        user_parts = [user_prompt_filled]
        if deque_history_str: user_parts.append(deque_history_str)
        if rag_history_str and retrieved_rag_history_snippets : user_parts.append(rag_history_str) # Only add if RAG found something distinct
        user_parts.append(instruction_for_new_commentary)

        # --- RAG for current game context (wiki, etc.) ---
        if profile.rag_collection_name and self.rag_service: # This is for factual game knowledge
            rag_query_current_context = formatted_ocr_string if formatted_ocr_string not in ["No text detected by OCR.", "OCR not performed or no text detected."] else f"General context for {profile.game_name}"
            current_context_snips = self.rag_service.query_rag(profile.rag_collection_name, rag_query_current_context, profile.rag_top_k) or []
            if current_context_snips:
                user_parts.append("\n\nRelevant game knowledge:\n" + "\n".join(current_context_snips))

        final_user_prompt = "\n".join(user_parts)
        # ... (payload creation and _call_llm_api as before) ...
        payload = { #/* ... as before ... */
            "model": profile.vlm_model,
            "messages": [{"role":"system","content":sys_prompt}, {"role":"user","content":final_user_prompt}],
            "images": images_for_vlm, "max_tokens": profile.vlm_max_tokens, "temperature": profile.vlm_temperature, "stream": False
        }
        resp = self._call_llm_api(payload)

        # --- Process Response and Update Memory ---
        if not resp or "choices" not in resp or not resp["choices"]: # Handle API failure
            self.logger.warning("Empty/invalid VLM response."); self.last_vlm_time = now; self.next_vlm_commentary_delay = self._calculate_next_commentary_delay(); return
        
        raw_commentary = resp["choices"][0].get("message",{}).get("content","").strip()
        if not raw_commentary: # Handle empty content
            self.logger.warning("VLM response content empty."); self.last_vlm_time = now; self.next_vlm_commentary_delay = self._calculate_next_commentary_delay(); return

        trimmed_commentary = trim_sentences(raw_commentary, profile.vlm_max_commentary_sentences)
        text_for_tts_and_discord = self._strip_markdown_for_tts(trimmed_commentary)

        if not text_for_tts_and_discord: # Handle empty after strip/trim
            self.logger.info("VLM commentary empty after processing."); self.last_vlm_time = now; self.next_vlm_commentary_delay = self._calculate_next_commentary_delay(); return

        # --- Update Hybrid Memory ---
        # 1. Add to Deque (e.g., first sentence as theme)
        theme_for_deque = text_for_tts_and_discord.split('.')[0].strip()
        if theme_for_deque:
            self.commentary_theme_history_deque.append(theme_for_deque)
            self.logger.debug(f"Added to deque history: '{theme_for_deque}'")

        # 2. Ingest full commentary into RAG history
        if self.rag_service and profile.memory_rag_history_collection_name:
            try:
                self.rag_service.ingest_text( # Assuming ingest_text can handle this
                    collection_name=profile.memory_rag_history_collection_name,
                    text_content=text_for_tts_and_discord, # Ingest the cleaned, final commentary
                    metadata={"timestamp": now, "source": "VLM_commentary", "game": profile.game_name, "theme": theme_for_deque}
                )
                self.logger.debug(f"Ingested VLM commentary into RAG history collection: {profile.memory_rag_history_collection_name}")
            except Exception as e_rag_ingest:
                self.logger.error(f"Failed to ingest VLM commentary into RAG history: {e_rag_ingest}", exc_info=True)
        # --- End Update Hybrid Memory ---

        # --- Queue for Discord ---
        # ... (queueing logic as before) ...
        discord_msg = f"🎙️ **{profile.game_name} Tip:** {text_for_tts_and_discord}"
        try:
            self.ctx.text_message_queue.put_nowait(discord_msg)
            if self.audio_service and gs.get("ENABLE_TTS_FOR_VLM_COMMENTARY", True):
                tts_audio = self.audio_service.fetch_tts_audio(text_for_tts_and_discord)
                if tts_audio: self.ctx.tts_queue.put_nowait(tts_audio)
        except queue.Full: self.logger.warning("Queues full, VLM commentary dropped.")
        
        self.last_vlm_time = now
        self.next_vlm_commentary_delay = self._calculate_next_commentary_delay()
        self.logger.info(f"VLM Commentary: \"{text_for_tts_and_discord}\". Next in ~{self.next_vlm_commentary_delay:.1f}s.")

    def run_vlm_commentary_loop(self):
        # ... (same as your last correct version, ensures latest frame is processed) ...
        self.logger.info("[LLMService] Starting VLM commentary loop.")
        time.sleep(self.ctx.global_settings.get("VLM_LOOP_STARTUP_DELAY_S", 3.0))
        while not self.ctx.shutdown_event.is_set():
            if not self.ctx.ndi_commentary_enabled.is_set(): time.sleep(1); continue
            latest_frame_np = None
            try:
                discarded_count = 0; q_size_before_get = self.ctx.frame_queue.qsize()
                while True:
                    try: temp_frame = self.ctx.frame_queue.get_nowait(); latest_frame_np = temp_frame; self.ctx.frame_queue.task_done()
                    except queue.Empty: break
                if latest_frame_np is not None:
                    if isinstance(latest_frame_np, np.ndarray): self.generate_vlm_commentary_from_frame(latest_frame_np)
                    else: self.logger.warning(f"Non-NumPy frame: {type(latest_frame_np)}")
            except Exception as e: self.logger.error(f"VLM loop error: {e}", exc_info=True)
            time.sleep(self.ctx.global_settings.get("VLM_LOOP_CHECK_INTERVAL_S", 1.0))
        self.logger.info("[LLMService] VLM commentary loop stopped.")


    def handle_user_text_query(self, user_text: str, user_name: str = "User"):
        profile = self.ctx.active_profile
        gs = self.ctx.global_settings
        self.logger.info(f"[LLMService] User query from '{user_name}': \"{user_text}\"")

        # --- Ingest User Query and Bot Previous Response (if any) into RAG history ---
        history_collection = profile.memory_rag_history_collection_name
        if self.rag_service and history_collection:
            try:
                self.rag_service.ingest_text(
                    collection_name=history_collection,
                    text_content=f"User ({user_name}): {user_text}", # Prefix with who said it
                    metadata={"timestamp": time.time(), "source": "user_query", "user": user_name, "game": profile.game_name}
                )
            except Exception as e_rag_ingest:
                self.logger.error(f"Failed to ingest user query into RAG history: {e_rag_ingest}")
        # --- End Ingest ---

        # --- Retrieve Chat History from RAG ---
        rag_chat_history_str = ""
        if self.rag_service and history_collection and profile.memory_rag_chat_lookback_k > 0:
            # Query with the current user text to find relevant past turns
            retrieved_chat_snippets = self.rag_service.query_rag(
                collection_name=history_collection,
                query_text=user_text, 
                top_k=profile.memory_rag_chat_lookback_k,
                # You might want to add metadata filters for 'source' being 'user_query' or 'bot_response'
                # and potentially filter by user_name if you want user-specific conversation history.
            ) or []
            if retrieved_chat_snippets:
                rag_chat_history_str = "\n\nRecent conversation context (newest first):\n"
                # Format them nicely, maybe just take the content part
                for snippet in reversed(retrieved_chat_snippets): # Newest first by reversing
                     # Assuming snippet is the text content. If it's a dict, use snippet['text_content']
                    rag_chat_history_str += f"- {snippet}\n" 
        # --- End Retrieve Chat History ---

        # --- RAG for current game knowledge (wiki, etc.) ---
        knowledge_rag_str = ""
        if profile.rag_collection_name and self.rag_service: # This is the general game knowledge RAG
            game_knowledge_snips = self.rag_service.query_rag(profile.rag_collection_name, user_text, profile.rag_top_k) or []
            if game_knowledge_snips:
                knowledge_rag_str = "\n\nRelevant game information:\n" + "\n".join(game_knowledge_snips)
        # --- End RAG for current game knowledge ---
        
        # --- Construct final prompt for conversational LLM ---
        sys_template = getattr(profile, 'system_prompt_chat', "You are {bot_name}, a helpful AI for {game_name}.")
        sys_prompt_chat = sys_template.format(game_name=profile.game_name, bot_name=gs.get("BOT_NAME", "DanzarVLM"))
        
        # Combine context: RAG chat history, then RAG game knowledge, then current user query
        prompt_elements = []
        if rag_chat_history_str: prompt_elements.append(rag_chat_history_str)
        if knowledge_rag_str: prompt_elements.append(knowledge_rag_str)
        prompt_elements.append(f"\nUser ({user_name}): {user_text}\nAI Response:") # Clearly mark current query

        final_user_prompt_for_chat = "\n".join(prompt_elements)

        conv_model = getattr(profile, 'conversational_llm_model', None) or profile.vlm_model
        if not conv_model: # Handle missing model
            self.logger.error("No model for chat."); self.ctx.text_message_queue.put("Chat not configured."); return

        payload = {
            "model": conv_model,
            "messages": [{"role":"system","content":sys_prompt_chat}, {"role":"user","content":final_user_prompt_for_chat}],
            "max_tokens": profile.conversational_max_tokens, "temperature": profile.conversational_temperature, "stream": False
        }
        
        resp = self._call_llm_api(payload)
        response_text = "Sorry, I had trouble formulating a response."
        if resp and "choices" in resp and resp["choices"]:
            content = resp["choices"][0].get("message",{}).get("content","").strip()
            if content: response_text = self._strip_markdown_for_tts(content) # Clean bot response too

        # --- Ingest Bot Response into RAG history ---
        if self.rag_service and history_collection:
            try:
                self.rag_service.ingest_text(
                    collection_name=history_collection,
                    text_content=f"AI ({gs.get('BOT_NAME', 'DanzarVLM')}): {response_text}", # Prefix with who said it
                    metadata={"timestamp": time.time(), "source": "bot_response", "game": profile.game_name}
                )
            except Exception as e_rag_ingest:
                 self.logger.error(f"Failed to ingest bot response into RAG history: {e_rag_ingest}")
        # --- End Ingest ---

        # --- Queue for Discord ---
        # ... (queueing logic as before) ...
        try:
            self.ctx.text_message_queue.put(f"💬 **{user_name}:** {user_text}\n🤖 **Reply:** {response_text}")
            if self.audio_service and gs.get("ENABLE_TTS_FOR_CHAT_REPLIES", True):
                tts_audio = self.audio_service.fetch_tts_audio(response_text)
                if tts_audio: self.ctx.tts_queue.put(tts_audio)
        except queue.Full: self.logger.warning("Queues full, chat response dropped.")
        
        self.logger.info(f"Conversational response: \"{response_text}\"")
        self.ctx.last_interaction_time = time.time()
        if gs.get("CLEAR_CONVERSATION_FLAG_AFTER_REPLY", True):
            self.ctx.is_in_conversation.clear()
            self.logger.info("Cleared is_in_conversation flag after user query.")