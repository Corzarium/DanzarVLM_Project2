# discord_integration/audio_sink.py
import discord
from discord.sinks import Sink as AudioSink # <--- Key change: Import from discord.sinks
# Or try: from discord.sinks.core import AudioSink if the above doesn't work

from typing import TYPE_CHECKING, Optional, Dict, List # Keep TYPE_CHECKING

if TYPE_CHECKING:
    from ..DanzarVLM import AppContext
    from ..services.audio_service import AudioService

class DanzarAudioSink(AudioSink): # <--- Use the imported/aliased AudioSink
    def __init__(self, app_context: 'AppContext', logger):
        super().__init__() 
        self.main_app_context = app_context
        self.audio_service: Optional['AudioService'] = getattr(app_context, 'audio_service_instance', None)
        self.logger = logger
        
        if not self.audio_service:
            self.logger.error("[DanzarAudioSink] CRITICAL: AudioService instance not found!")
        else:
            self.logger.info("[DanzarAudioSink] Instance created, linked.")

    def write(self, data: discord.sinks.core.AudioData, user: Optional[discord.User]):
        if not user: return
        user_id = user.id
        if not self.audio_service: return
        try:
            self.audio_service.process_discord_audio_chunk(bytes(data.pcm_array), user_id)
        except Exception as e:
            self.logger.error(f"[DanzarAudioSink] Error processing audio for user {user_id}: {e}", exc_info=True)

    def cleanup(self):
        self.logger.info("[DanzarAudioSink] Cleanup called.")