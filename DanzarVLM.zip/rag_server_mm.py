#!/usr/bin/env python3
# rag_server_mm.py

import os
import io
import base64
import time
import threading

from flask import Flask, request, jsonify
from PIL import Image
import torch
import requests

from sentence_transformers import SentenceTransformer
from transformers import BlipProcessor, BlipModel

import chromadb
from chromadb.config import Settings

# ─── CONFIGURATION ─────────────────────────────────────────────────────────
PERSIST_DIR       = "chroma_rag_db"
TEXT_MODEL_NAME   = "sentence-transformers/all-MiniLM-L6-v2"
IMAGE_MODEL_NAME  = "Salesforce/blip-image-captioning-base"
SERVER_PORT       = 5000

# llama.cpp server (multimodal) endpoint
LLM_URL = os.environ.get(
    "LLM_URL",
    "http://172.17.117.23:8080/v1/completions") # Ensure this is your Llama.cpp server URL
LLM_MODEL         = ""  # Set to "" to NOT send the model parameter, or specify if needed
                        # e.g., "your_model_alias" if you used --alias in llama-server

os.makedirs(PERSIST_DIR, exist_ok=True)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ─── EMBEDDERS ─────────────────────────────────────────────────────────────
print(f"Loading text model: {TEXT_MODEL_NAME}...")
text_encoder  = SentenceTransformer(TEXT_MODEL_NAME).to(device)
print(f"Loading image model: {IMAGE_MODEL_NAME}...")
img_processor = BlipProcessor.from_pretrained(IMAGE_MODEL_NAME)
img_model     = BlipModel.from_pretrained(IMAGE_MODEL_NAME).to(device)
print("Models loaded.")

def embed_text(text: str) -> list[float]:
    return text_encoder.encode(text).tolist()

def embed_image_b64(data_uri: str, caption: str="") -> list[float]:
    header, b64 = data_uri.split(",", 1) if "," in data_uri else ("", data_uri)
    img_bytes = base64.b64decode(b64)
    image = Image.open(io.BytesIO(img_bytes)).convert("RGB")

    inputs = img_processor(images=image, text=caption, return_tensors="pt").to(device)
    with torch.no_grad():
        outputs = img_model(**inputs)
        if hasattr(outputs, "pooler_output") and outputs.pooler_output is not None:
            emb = outputs.pooler_output
        elif hasattr(outputs, "last_hidden_state"):
            emb = outputs.last_hidden_state[:, 0, :]
        else:
            # Fallback to caption embedding if image embedding fails unexpectedly
            print("Warning: Could not get pooled or last hidden state from image model, using caption embedding.")
            return embed_text(caption or "blank image") # Ensure some embedding is returned
    return emb.squeeze().cpu().tolist()

# ─── CHROMA DB SETUP ────────────────────────────────────────────────────────
client     = chromadb.PersistentClient(path=PERSIST_DIR)
collection = client.get_or_create_collection(name="multimodal_rag")
add_lock   = threading.Lock()

# ─── LLM CALL HELPER ────────────────────────────────────────────────────────
def call_llm(prompt: str, images: list[str]=None, stream: bool=False) -> str:
    """
    Send prompt (+ optional base64 images) to llama.cpp HTTP server and
    return the text reply.
    """
    payload = {
        "prompt": prompt,
        "stream": stream,
        "n_predict": 512,  # Max tokens to generate, adjust as needed
        # "temperature": 0.7, # Optional: Add other Llama.cpp parameters
        # "top_p": 0.9,       # Optional
    }

    # Only add the 'model' key if LLM_MODEL is explicitly set
    if LLM_MODEL:
        payload["model"] = LLM_MODEL

    if images:
        # Llama.cpp /v1/completions for multimodal models like LLaVA expects image_data
        # in a specific format. The "images" key might be for older/custom versions.
        # Common format: payload["image_data"] = [{"data": b64_str, "id": idx}, ...]
        # Sticking to your "images" key for now, but ensure it's just raw base64.
        processed_images = []
        for idx, data_uri in enumerate(images):
            # Strip data URI prefix (e.g., "data:image/jpeg;base64,") if present
            _header, b64_data = data_uri.split(",", 1) if "," in data_uri else ("", data_uri)
            processed_images.append(b64_data) # Llama.cpp expects raw base64 string
        payload["images"] = processed_images
        # If your Llama.cpp expects the 'image_data' structure:
        # payload["image_data"] = [{"data": b64_data, "id": idx} for idx, b64_data in enumerate(processed_images)]
        # del payload["images"] # if using image_data

    print(f"DEBUG: Sending to LLM ({LLM_URL}) payload: { {k: v if k != 'images' else '[...images...]' for k, v in payload.items()} }") # Avoid printing long image strings

    try:
        resp = requests.post(LLM_URL, json=payload, timeout=180) # Increased timeout for LLM
        resp.raise_for_status()  # Raises HTTPError for bad responses (4XX or 5XX)
        data = resp.json()

        # Standard OpenAI-compatible /v1/completions endpoint:
        if "choices" in data and data["choices"]:
            choice = data["choices"][0]
            if "text" in choice:
                return choice["text"].strip()
            # Handle if llama.cpp server is using /v1/chat/completions format even for /v1/completions
            elif "message" in choice and "content" in choice["message"]:
                 return choice["message"]["content"].strip()

        print(f"WARN: LLM response 'choices' or expected text field missing: {data}")
        return f"Error: LLM response format unexpected. Data: {data}"

    except requests.exceptions.Timeout:
        print(f"ERROR: LLM call timed out after 180 seconds to {LLM_URL}")
        raise Exception("LLM call timed out")
    except requests.exceptions.RequestException as e:
        print(f"ERROR: LLM request failed: {e}")
        if hasattr(e, 'response') and e.response is not None:
            print(f"ERROR: LLM response status code: {e.response.status_code}")
            print(f"ERROR: LLM response content: {e.response.text}")
        raise # Re-raise the exception to be caught by the route handler

# ─── FLASK APP ─────────────────────────────────────────────────────────────
app = Flask(__name__)

@app.route("/add", methods=["POST"])
def add():
    """
    Ingest text or image into the RAG store.
    Body: { "text": "..."} or { "image": "data:...,", "caption": "..."}
    """
    data = request.get_json(force=True) or {}
    doc = None
    meta = None
    vec = None

    if "text" in data:
        text_content = data["text"]
        if not text_content.strip():
            return jsonify({"error": "Text content cannot be empty"}), 400
        vec, doc, meta = embed_text(text_content), text_content, {"type": "text"}
    elif "image" in data:
        image_data_uri = data["image"]
        if not image_data_uri:
             return jsonify({"error": "Image data URI cannot be empty"}), 400
        caption = data.get("caption", "") # Caption is optional but recommended
        vec = embed_image_b64(image_data_uri, caption)
        # Store data URI or a placeholder for the document.
        # Storing full data URI can make DB large. Consider storing paths if files are saved.
        doc = f"<image_data_uri>" # Placeholder, or store data_uri if small enough / needed
        meta = {"type": "image", "caption": caption, "original_data_uri_ref": image_data_uri[:100] + "..."} # Store ref
    else:
        return jsonify({"error": "Must supply 'text' or 'image' in JSON body"}), 400

    entry_id = str(int(time.time() * 1e6)) # Simple timestamp-based ID
    with add_lock:
        collection.add(
            ids=[entry_id],
            embeddings=[vec],
            documents=[doc], # doc is <image_data_uri> or the text
            metadatas=[meta]
        )
    return jsonify({"status": "added", "id": entry_id, "type": meta["type"]}), 200

@app.route("/query", methods=["POST"])
def query():
    """
    Query the RAG store and then call the LLM with retrieved context.
    Body: { "query": "...", "images": [ optional list of base64 images for multimodal query ] }
    """
    data = request.get_json(force=True) or {}
    q = data.get("query", "").strip()
    if not q:
        return jsonify({"error": "No query provided"}), 400

    # 1) Retrieve from ChromaDB
    qvec    = embed_text(q)
    try:
        results = collection.query(query_embeddings=[qvec], n_results=5) # Get top 5 results
    except Exception as e:
        print(f"Error querying ChromaDB: {e}")
        return jsonify({"error": f"ChromaDB query failed: {e}"}), 500

    sources = []
    if results and results.get("documents") and results["documents"][0]:
        for doc, meta, dist in zip(
            results["documents"][0],
            results["metadatas"][0],
            results["distances"][0]
        ):
            source_text = doc
            if meta["type"] == "image":
                source_text = f"Image" # Use caption or a placeholder for image context
                if meta.get("caption"):
                    source_text += f" with caption: {meta['caption']}"
            sources.append({
                "type":    meta["type"],
                "text":    source_text, # This is what goes into the LLM context
                "caption": meta.get("caption", ""), # Keep caption separate for display if needed
                "score":   dist
            })
    else:
        print("No results found in ChromaDB for the query.")


    # 2) Build prompt with context
    context_parts = []
    if sources:
        context_parts.append("Retrieved context:")
        for s in sources:
            if s['type'] == 'text':
                context_parts.append(f"- [Text Document] {s['text']}")
            elif s['type'] == 'image':
                context_parts.append(f"- [Image] Caption: '{s['caption']}'") # Focus on caption for context
    else:
        context_parts.append("No relevant context found in the knowledge base.")

    context_str = "\n".join(context_parts)

    # User question needs to be clearly identifiable for the LLM,
    # especially if images are part of the query to the LLM.
    # For LLaVA style models, prompt often looks like: "USER: <image_placeholder_if_any> Question?\nASSISTANT:"
    # or simply "<image_placeholder_if_any>\nQuestion"

    # If query images are provided, LLaVA typically expects placeholders like <image> or [IMG] in the prompt.
    # The exact placeholder and format depend on how llama.cpp server and the model handle it.
    # For now, we'll just prepend the question with "Question:"
    # If you send images to `call_llm`, ensure your Llama.cpp server and model support it.
    # The prompt structure might need adjustment for multimodal queries.

    prompt_prefix_for_llm = ""
    query_images = data.get("images") # list of base64 data URIs
    if query_images:
        # Assuming Llama.cpp server with LLaVA model, it might replace <image> tokens.
        # You might need to add one <image> token per image in the prompt.
        # For simplicity, let's just indicate images are present.
        # The `call_llm` function will pass the `images` payload.
        # The prompt itself might not need explicit <image> tokens if the server
        # handles multimodal input automatically based on the 'images' payload.
        # Check Llama.cpp documentation for your specific multimodal model.
        prompt_prefix_for_llm = "Considering the provided image(s) and the following context:\n"
    else:
        prompt_prefix_for_llm = "Use the following context to answer the question:\n"


    full_prompt = (
        f"{prompt_prefix_for_llm}\n"
        f"{context_str}\n\n"
        f"Question: {q}\n\n"
        "Answer:"
    )
    print(f"\n--- Full Prompt for LLM ---\n{full_prompt}\n---------------------------\n")

    # 3) Call the multimodal LLM
    try:
        answer = call_llm(full_prompt, images=query_images) # Pass query images if any
    except Exception as e:
        # The error from call_llm (including response text if any) will be part of 'e'
        return jsonify({"error": f"LLM call failed: {e}"}), 500

    return jsonify({
        "query":   q,
        "sources": sources,
        "answer":  answer,
        "llm_prompt_sent": full_prompt # For debugging what was sent
    }), 200

if __name__ == "__main__":
    print(f"Starting RAG+LLM server on 0.0.0.0:{SERVER_PORT}, DB at '{PERSIST_DIR}'")
    print(f"LLM endpoint: {LLM_URL}")
    if LLM_MODEL:
        print(f"LLM model specified: {LLM_MODEL}")
    else:
        print(f"LLM model: Not specified (will use server default)")
    app.run(host="0.0.0.0", port=SERVER_PORT, debug=False) # debug=True can cause issues with some model loading
